// ─────────────────────────────────────────────────────────────
//  P.S. — Phelps Softwares Account · identity SDK
//
//  One account across all Phelps Softwares products (starting with
//  Phelps Linux). SEPARATE from Jack Account — its own Firebase
//  project and user pool. An app imports this module and gets
//  sign-in + a Firestore handle.
//
//  Usage:
//     import { PSAccount } from "./ps/psaccount.js";
//     PSAccount.onAuthState(user => { ... });
//     await PSAccount.signUp("jack", "pw", "Jack Phelps");  // username OR email
//     await PSAccount.signIn("jack", "pw");
//     await PSAccount.signInWithGoogle();                   // served origins only
//     PSAccount.uid();  PSAccount.name();  await PSAccount.signOut();
//
//  NOTE: ES-module + Firebase need a real origin — serve over
//  http://localhost (not file://). See ps/README.md.
// ─────────────────────────────────────────────────────────────
import { initializeApp, getApps } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import {
  getAuth, setPersistence, browserLocalPersistence,
  createUserWithEmailAndPassword, signInWithEmailAndPassword,
  signInWithPopup, GoogleAuthProvider,
  onAuthStateChanged, signOut as fbSignOut, updateProfile,
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";
import {
  getFirestore, doc, getDoc, setDoc, serverTimestamp,
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

import { firebaseConfig, USERNAME_DOMAIN } from "./config.js";

export const PS_CONFIGURED = firebaseConfig.apiKey && firebaseConfig.apiKey !== "PASTE_ME";

const app  = getApps().find((a) => a.name === "psaccount")
             ?? initializeApp(firebaseConfig, "psaccount");
const auth = getAuth(app);
const db   = getFirestore(app);
setPersistence(auth, browserLocalPersistence).catch(() => {});

function emailFor(id) {
  const s = String(id || "").trim();
  if (s.includes("@")) return s;
  return `${s.toLowerCase().replace(/[^a-z0-9_.-]/g, "")}@${USERNAME_DOMAIN}`;
}
const isUsername = (id) => !String(id || "").includes("@");

async function ensureProfile(user, { username, displayName } = {}) {
  if (!user) return;
  const ref = doc(db, "users", user.uid);
  const snap = await getDoc(ref);
  const base = {
    uid: user.uid,
    displayName: displayName || user.displayName || username || "Phelps user",
    lastSeen: serverTimestamp(),
  };
  if (!snap.exists()) {
    await setDoc(ref, {
      ...base,
      username: username || null,
      email: user.email || null,
      provider: user.providerData?.[0]?.providerId || "password",
      product: "phelps-linux",
      createdAt: serverTimestamp(),
    });
  } else {
    await setDoc(ref, base, { merge: true });
  }
}

export const PSAccount = {
  app, auth, db,
  current() { return auth.currentUser; },
  uid() { return auth.currentUser?.uid || null; },
  name() { return auth.currentUser?.displayName || null; },
  onAuthState(cb) { return onAuthStateChanged(auth, cb); },

  async signUp(identifier, password, displayName) {
    const cred = await createUserWithEmailAndPassword(auth, emailFor(identifier), password);
    const name = displayName || (isUsername(identifier) ? identifier : identifier.split("@")[0]);
    try { await updateProfile(cred.user, { displayName: name }); } catch {}
    await ensureProfile(cred.user, { username: isUsername(identifier) ? identifier.toLowerCase() : null, displayName: name });
    return cred.user;
  },
  async signIn(identifier, password) {
    const cred = await signInWithEmailAndPassword(auth, emailFor(identifier), password);
    await ensureProfile(cred.user, { username: isUsername(identifier) ? identifier.toLowerCase() : null });
    return cred.user;
  },
  async signInWithGoogle() {
    const cred = await signInWithPopup(auth, new GoogleAuthProvider());
    await ensureProfile(cred.user, { displayName: cred.user.displayName });
    return cred.user;
  },
  async signOut() { return fbSignOut(auth); },
  async idToken(force = false) { return auth.currentUser ? auth.currentUser.getIdToken(force) : null; },
};

export default PSAccount;
