// ─────────────────────────────────────────────────────────────
//  P.S. — Phelps Softwares Account · Firebase config
//
//  A BRAND-NEW, SEPARATE Firebase project from Jack Account.
//  Its own user pool. These web keys are PUBLIC by design (safe to
//  commit) — real security is the Firestore rules, not hiding keys.
// ─────────────────────────────────────────────────────────────
export const firebaseConfig = {
  apiKey:            "AIzaSyAyh_p1jcgr8Uy6_iaieuyMjwGfae11heY",
  authDomain:        "ps-account.firebaseapp.com",
  projectId:         "ps-account",
  storageBucket:     "ps-account.firebasestorage.app",
  messagingSenderId: "192800901",
  appId:             "1:192800901:web:ce1c1ad17144267f65a1ec",
  measurementId:     "G-YZ108ELW0R",
};

// Usernames (no "@") become an internal email so people can sign up
// with just a username + password, no real email required.
export const USERNAME_DOMAIN = "phelps.id";
