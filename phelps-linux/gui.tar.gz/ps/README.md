# P.S. — Phelps Softwares Account

A brand-new, **separate** identity system for Phelps Softwares products
(starting with Phelps Linux). Not connected to Jack Account — its own
Firebase project and user pool.

## One-time Firebase console setup (do this once)

1. **Create the project**
   - Go to https://console.firebase.google.com → **Add project**
   - Name it `phelps-softwares` (or `phelps-account`). Disable Analytics (optional). Create.

2. **Add a Web app**
   - In the project, click the **`</>`** (Web) icon → nickname `ps-web` → Register.
   - It shows a `firebaseConfig = { ... }` block. **Copy those 6 values.**
   - Paste them into `ps/config.js` (replace every `PASTE_ME`).

3. **Enable Email/Password auth**
   - Build → **Authentication** → Get started → **Sign-in method**
   - Enable **Email/Password**. (Optional: enable **Google** too.)

4. **Create Firestore**
   - Build → **Firestore Database** → Create database → **Production mode** → pick a location.
   - Open the **Rules** tab, paste the contents of `ps/firestore.rules`, **Publish**.

5. **Authorize your domains** (only needed for Google sign-in / when deployed)
   - Authentication → Settings → **Authorized domains** → add `localhost`
     and later your GitHub Pages domain.

## Running the simulator with accounts

ES-modules + Firebase need a real origin (not `file://`). From `~/phelps-linux`:

```
python3 -m http.server 8000
```

Then open **http://localhost:8000/gui/** — the P.S. step now creates/signs
in real accounts against your new project.

Usernames with no `@` map to `<name>@phelps.id` internally (so people can sign
up with just a username + password, no email required).
