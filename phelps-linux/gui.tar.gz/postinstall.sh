#!/bin/sh
# Phelps Linux 2.0 "Weymouth" — system setup applied by software updates.
# Runs as ROOT via do-update.sh. Must be idempotent (runs on every update).
set -u
log(){ echo "[postinstall] $*"; }

# --- 1) Laptop lid close -> suspend to RAM ---------------------------------
if command -v acpid >/dev/null 2>&1; then
  mkdir -p /etc/acpi/events
  cat > /etc/acpi/phelps-lid-close.sh <<'EOS'
#!/bin/sh
# Lid was closed — suspend to RAM. Resumes when the lid opens.
echo mem > /sys/power/state 2>/dev/null
EOS
  chmod +x /etc/acpi/phelps-lid-close.sh
  cat > /etc/acpi/events/phelps-lid <<'EOS'
event=button/lid.*close
action=/etc/acpi/phelps-lid-close.sh
EOS
  rc-update add acpid default 2>/dev/null
  rc-service acpid restart 2>/dev/null || rc-service acpid start 2>/dev/null || true
  log "lid-close suspend configured"
else
  log "acpid not installed yet (will configure next update)"
fi

# --- 2) Ctrl+Alt+Q exits a full-screen non-Phelps app (Firefox/LibreOffice) -
if command -v thd >/dev/null 2>&1; then
  mkdir -p /etc/triggerhappy/triggers.d
  cat > /etc/triggerhappy/triggers.d/phelps.conf <<'EOS'
# Return to the Phelps desktop from a full-screen app
KEY_LEFTCTRL+KEY_LEFTALT+KEY_Q     1   sh -c 'pkill -x firefox; pkill -f soffice.bin'
KEY_RIGHTCTRL+KEY_RIGHTALT+KEY_Q   1   sh -c 'pkill -x firefox; pkill -f soffice.bin'
EOS
  rc-update add triggerhappy default 2>/dev/null
  rc-service triggerhappy restart 2>/dev/null || rc-service triggerhappy start 2>/dev/null || true
  log "Ctrl+Alt+Q app-exit hotkey configured"
else
  log "triggerhappy not installed yet (will configure next update)"
fi

exit 0
