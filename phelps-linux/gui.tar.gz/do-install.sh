#!/bin/sh
# Phelps Linux — the actual installer. Run detached by cgi-bin/install?action=start.
# Clones the booted system onto an internal disk, fixes the GPT, and grows the
# root filesystem to fill the drive. Target disk is read from a temp file that
# cgi-bin/install writes AFTER validating it.
#   progress% -> /tmp/phelps-install.pct   state -> /tmp/phelps-install.status
LOG=/tmp/phelps-install.log
ST=/tmp/phelps-install.status
PCT=/tmp/phelps-install.pct

exec >"$LOG" 2>&1
set -x
echo running > "$ST"; echo 0 > "$PCT"

TGT=$(cat /tmp/phelps-install.target 2>/dev/null)
[ -n "$TGT" ] || { echo "no target"; echo fail > "$ST"; exit 1; }
DST="/dev/$TGT"

# Re-derive the source disk here too (never trust only the caller).
rootpart=$(findmnt -n -o SOURCE / 2>/dev/null)
SRCDISK=$(lsblk -no PKNAME "$rootpart" 2>/dev/null | head -1)
[ -n "$SRCDISK" ] || SRCDISK=$(printf '%s' "$rootpart" | sed 's@.*/@@; s/p\{0,1\}[0-9]*$//')
SRC="/dev/$SRCDISK"

# Hard safety: never write to the disk we booted from, and target must exist.
[ "$TGT" = "$SRCDISK" ] && { echo "refuse: target is the source disk"; echo fail > "$ST"; exit 1; }
[ -b "$DST" ]          || { echo "refuse: $DST is not a block device"; echo fail > "$ST"; exit 1; }
[ -b "$SRC" ]          || { echo "refuse: cannot find source disk";    echo fail > "$ST"; exit 1; }

BS=4194304          # 4 MiB
COUNT=768           # 768 * 4 MiB = 3072 MiB == the Phelps image size

echo "Cloning $SRC -> $DST  ($COUNT x 4MiB = 3072MiB)…"
sync
i=0
while [ "$i" -lt "$COUNT" ]; do
  if ! dd if="$SRC" of="$DST" bs="$BS" skip="$i" seek="$i" count=1 conv=notrunc 2>/dev/null; then
    echo "dd failed at block $i"; echo fail > "$ST"; exit 1
  fi
  i=$((i + 1))
  echo $(( i * 100 / COUNT )) > "$PCT"
done
sync
echo "Clone complete."

echo "Reloading partition table on $DST…"
partprobe "$DST" 2>/dev/null || partx -u "$DST" 2>/dev/null || true

# root partition node (nvme/mmc use pN; sata/usb use N)
case "$TGT" in nvme*|mmcblk*) P2="${DST}p2";; *) P2="${DST}2";; esac

echo "Moving GPT backup header to the end of the disk…"
command -v sgdisk >/dev/null 2>&1 && sgdisk -e "$DST" 2>/dev/null || echo "(sgdisk not available — skipping)"
partprobe "$DST" 2>/dev/null || true

echo "Growing the root partition + filesystem to fill $DST…"
if command -v parted >/dev/null 2>&1; then
  parted -s "$DST" resizepart 2 100% 2>/dev/null || echo "(resizepart skipped)"
  partprobe "$DST" 2>/dev/null || true
fi
if command -v resize2fs >/dev/null 2>&1 && [ -b "$P2" ]; then
  e2fsck -fy "$P2" 2>/dev/null || true
  resize2fs "$P2" 2>/dev/null || echo "(resize2fs skipped)"
else
  echo "(resize2fs not available — root stays at its cloned size)"
fi

echo 100 > "$PCT"
echo "done"
echo done > "$ST"
