#!/bin/sh
# Phelps Linux — the actual updater. Run detached by cgi-bin/update?action=install.
# Downloads the latest bundle (your whole desktop/apps) + any packages it lists,
# swaps it in, bumps the version, and restarts the local web server.
# Progress -> /tmp/phelps-update.log ; coarse state -> /tmp/phelps-update.status
BASE="https://jcakphleps.github.io/phelps-linux"
GUI="/opt/phelps/gui"
LOG="/tmp/phelps-update.log"
STATUS="/tmp/phelps-update.status"

exec >"$LOG" 2>&1
set -x
echo "running" > "$STATUS"

jget(){ sed -n 's/.*"'"$1"'"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' | head -1; }

cd /tmp || { echo fail > "$STATUS"; exit 1; }

echo "Downloading update manifest…"
curl -fsSL --max-time 30 "$BASE/latest.json" -o latest.json || { echo "fail" > "$STATUS"; exit 1; }

VER=$(jget version   < latest.json)
BUNDLE=$(jget bundle < latest.json)
[ -n "$BUNDLE" ] || BUNDLE="$BASE/gui.tar.gz"
# packages: pull the array body between [ ... ], strip quotes, commas -> spaces
PKGS=$(sed -n 's/.*"packages"[[:space:]]*:[[:space:]]*\[\([^]]*\)\].*/\1/p' latest.json | tr -d '"' | tr ',' ' ')

echo "Downloading bundle: $BUNDLE"
curl -fsSL --max-time 180 "$BUNDLE" -o gui.tar.gz || { echo "fail" > "$STATUS"; exit 1; }

echo "Unpacking…"
rm -rf /tmp/gui.new && mkdir -p /tmp/gui.new
tar xzf gui.tar.gz -C /tmp/gui.new || { echo "fail" > "$STATUS"; exit 1; }

echo "Installing new desktop…"
cp -a /tmp/gui.new/. "$GUI"/ || { echo "fail" > "$STATUS"; exit 1; }
chmod +x "$GUI"/cgi-bin/* "$GUI"/do-update.sh 2>/dev/null
[ -n "$VER" ] && printf '%s\n' "$VER" > "$GUI/VERSION"

if [ -n "$PKGS" ]; then
  echo "Installing packages: $PKGS"
  apk update  || echo "apk update failed (continuing)"
  apk add $PKGS || echo "apk add failed (continuing)"
fi

echo "Restarting desktop server…"
rc-service phelps-www restart 2>/dev/null || /etc/init.d/phelps-www restart 2>/dev/null || true

echo "done"
echo "done" > "$STATUS"
